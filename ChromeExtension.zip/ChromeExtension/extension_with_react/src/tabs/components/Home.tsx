import React from 'react'

function Home() {
    return (
        <div>
            Hello, Home
        </div >

    )
}

export default Home
chrome.runtime.onInstalled.addListener(() => {
    console.log('I just installed my extension')
  });

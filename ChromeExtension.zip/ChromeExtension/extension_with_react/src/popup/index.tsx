import React from 'react';
import Tooltip from './Tooltip';

const App: React.FC = () => {
  return (
    <div className="App">
      <Tooltip />
    </div>
  );
};

export default App;
